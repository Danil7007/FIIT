// hrackarsky tabulkovy procesor: 2D pole struktur pre vyrazy alebo hodnoty
// vyuzitie unionu a vymenovaneho typu 
#include <stdio.h>
#include <ctype.h>
#define MAXR 10 // pocet riadkov
#define MAXS ('E' - 'A' + 1) // pocet stlpcov
#define NPRIKAZ 10 //maximalna dlzka prikazu

// vymenovany typ: vyraz alebo cislo
typedef enum {
    VYR, CIS
} TYP;

// struktura pre vyraz
typedef struct {
	char oper;
	double l_operand;
	double r_operand;
} VYRAZ;

// struktura pre bunku tabulk s unionom - bud vyraz alebo hodnota
typedef struct {
	TYP typ;
	union {
		VYRAZ vyraz;
		double cislo;
	} hodnota;
} BUNKA;

void inicializuj(BUNKA excel[][MAXS], int r);
void priradit_vyraz(BUNKA excel[][MAXS], int i, int j, char prikaz[]);
double vypocitaj(VYRAZ v);
void vypis_hodnoty(BUNKA excel[][MAXS], int r);
void vypis_vyrazy(BUNKA excel[][MAXS], int r);

// hlavna funkcia
int main() 
{
	BUNKA excel[MAXR][MAXS];  // tabulka: 2D staticke pole
   	int i=0, j=0;			 // index aktualnej pozicie kurzora
   	char c;
   	char prikaz[NPRIKAZ];     // pole znakov pre nacitanie prikazu

   	inicializuj(excel, MAXR);

   	do {
    	printf("\n*** TABULKOVY PROCESOR ***\n");
    	printf("= priradene: format =o(c1,c2) alebo =cislo\n");
    	printf("p presun kurzora: format prs\n");
    	printf("h vypis hodnot \nv vypis vyrazov\n");
    	printf("k koniec\n");
    	printf("\nKurzor: %c%d\n\n", j+'A', i);
    	gets(prikaz);
     
     	switch (tolower(prikaz[0])) {
     		case '=': priradit_vyraz(excel, i, j, prikaz); 
        		break;
     		case 'p': 
        		if (sscanf(prikaz+1, "%c %d", &c, &i) != 2) { 
            		printf("Nespravny format vstupu.\n"); 
	      			break;
	   			}
         		if ((j = toupper(c)-'A') >= MAXS) j = MAXS - 1;
         		if (j < 0) j = 0;
         		if (i < 0) i = 0;
         		if (i >= MAXR) i = MAXR - 1;
         		break;
      		case 'h': vypis_hodnoty(excel, MAXR); break;
      		case 'v': vypis_vyrazy(excel, MAXR); break;
      		case 'k': break; 
      		default: break;
		}
   	} while (prikaz[0] != 'k');
   	return 0;
}  

// inicializacia: vynulovanie vsetkych buniek, typ: cislo
void inicializuj(BUNKA excel[][MAXS], int r) {
   	int i, j;
	
   	for (i=0; i<r; i++)
      	for (j=0; j<MAXS; j++) {
         	excel[i][j].typ = CIS;
         	excel[i][j].hodnota.cislo = 0.0;
      	}
}

// vypis hodnot: pre vyrazy sa vypocita hodnota
void vypis_hodnoty(BUNKA excel[][MAXS], int r) {
   	int i, j;

   	printf("VYPIS HODNOT:\n ");
   	for (i=0; i<MAXS; i++) 
      	printf("       %c", 'A'+i);
   	putchar('\n');

   	for (i=0; i<r; i++) {
       	printf("%d ", i);
       	for (j=0; j<MAXS; j++) {
          	if(excel[i][j].typ == CIS)
             	printf("%7.2f ", excel[i][j].hodnota.cislo);
          	else 
             	printf("%7.2f ", vypocitaj(excel[i][j].hodnota.vyraz));
       	}
       	putchar('\n');
   	}
}

// vypocita hodnotu vyrazu
double vypocitaj(VYRAZ v) 
{
   	switch (v.oper) {
   		case '+': 
      		return v.l_operand + v.r_operand; break;
   		case '-': 
      		return v.l_operand - v.r_operand; break;
   		case '*': 
      		return v.l_operand * v.r_operand; break;
   		case '/': 
      		return v.l_operand / v.r_operand; break;
   		default: return 0.0; 
   	}
}

// vypis vyrazov 
void vypis_vyrazy(BUNKA excel[][MAXS], int r) {
   	int i, j;
   	printf("VYPIS VYRAZOV:\n ");
   	for (i=0; i<MAXS; i++) 
       	printf("           %c", 'A'+i);
   	putchar('\n');
   	for (i=0; i<r; i++) {
      	printf("%d ", i);
      	for (j=0; j<MAXS; j++) {
         	if(excel[i][j].typ == CIS)
            	printf("%11.2f ", excel[i][j].hodnota.cislo);
         	else 
            	printf("%c(%.1f, %.1f) ", 
               		excel[i][j].hodnota.vyraz.oper, 
               		excel[i][j].hodnota.vyraz.l_operand, 
               		excel[i][j].hodnota.vyraz.r_operand);
      	}
      	putchar('\n');
   	}
}

// priradenie hodnty alebo vyrazu do bunky na aktualnu poziciu kurzora i,j
void priradit_vyraz(BUNKA excel[][MAXS], int i, int j, char prikaz[]) {
    char c;

   	if (sscanf(&prikaz[1], "%c", &c) != 1) {
      	printf("Nespravny format.\n");
      	return;
   	}
   	if (c == '+' || c == '-' || c == '*' || c == '/') {
      	double x, y;
      	if (sscanf(&prikaz[1], "%c(%lf,%lf)", &c, &x, &y) != 3) {
         	printf("Nespravny format.\n");
      	   	return;
      	}
      	excel[i][j].typ = VYR;
      	excel[i][j].hodnota.vyraz.oper = c;
      	excel[i][j].hodnota.vyraz.l_operand = x;
      	excel[i][j].hodnota.vyraz.r_operand = y;
   	}	   
	else {
      	double x;
		if (sscanf(&prikaz[1], "%lf", &x) != 1) {
			printf("Nespravny format.\n");
			return;
		}
		excel[i][j].typ = CIS;
		excel[i][j].hodnota.cislo = x;
	}
}

