#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#define NSTR 50 /* dlzka retazcov znakov */
#define NNAZOV 1000 /* maximalna dlzka retazca znakov pri nacitavani nadpisu */
#define NBLOK 3
#define SUBOR "kniznica.txt"

typedef struct {
	char meno[NSTR];
	char priezvisko[NSTR];
} AUTOR;

typedef struct {  
	char *nazov;
	AUTOR autor;
	int rok;
} KNIHA;


KNIHA *nacitaj(KNIHA *kniznica, int *pocet, int *velkost) {
	FILE *f;
	char nazovKnihy[NNAZOV];
	int i;
	
	if((f = fopen(SUBOR, "r")) == NULL) {
		printf("Nepodarilo sa otvorit subor\n");
		return kniznica;
	}
	i = 0;
	while (fscanf(f, "%s", nazovKnihy) == 1) {
		// ak treba akokovat alebo realokovat
		if (i >= *velkost) {
			if (*velkost == 0)
				kniznica = (KNIHA *) malloc(NBLOK * sizeof(KNIHA)); // kniznica nie je vytvorena
			else  // kniznicu treba zvacsit
				kniznica = (KNIHA *) realloc(kniznica, (*velkost + NBLOK) * sizeof(KNIHA));
			*velkost += NBLOK;
		}
		kniznica[i].nazov = (char *) malloc(strlen(nazovKnihy) + 1);
		strcpy(kniznica[i].nazov, nazovKnihy);
		fscanf(f, "%s", kniznica[i].autor.meno);
		fscanf(f, "%s", kniznica[i].autor.priezvisko);
		fscanf(f, "%d", &kniznica[i].rok);
		i++;
	}
	fclose(f);
	*pocet = i;
	return kniznica;
}

void vypis(KNIHA *kniznica, int n, int velkost)  
{
   int i;

   	printf("\nKNIZNICA\n");
   	printf("Velkost kniznice: %d, pocet knih: %d\n", velkost, n);
   	for (i=0; i<n; i++) 
      	printf("%s %s: %s (%d)\n", kniznica[i].autor.meno, 
      	kniznica[i].autor.priezvisko, kniznica[i].nazov, 
      	kniznica[i].rok);
   	printf("\n\n");
}

void pridaj(KNIHA **kniznica, int *pocet, int *velkost) {
	char nazovKnihy[NNAZOV];
	
	printf("Zadajte nazov knihy: ");
	scanf("%s", nazovKnihy);
   
   	if (*velkost == 0) {
   		*kniznica = (KNIHA *) malloc(NBLOK * sizeof(KNIHA));
		*velkost = NBLOK;
	}	
   	else if ((*pocet+1) > *velkost) {
		*kniznica = (KNIHA *) realloc(*kniznica, (*velkost + NBLOK) * sizeof(KNIHA));
		*velkost += NBLOK;
	}
	(*kniznica)[*pocet].nazov = (char *) malloc(strlen(nazovKnihy) + 1);
	strcpy((*kniznica)[*pocet].nazov, nazovKnihy);
	printf("Zadajte meno autora:  ");
	scanf("%s", (*kniznica)[*pocet].autor.meno);
	printf("Zadajte priezvisko autora:  ");
	scanf("%s", (*kniznica)[*pocet].autor.priezvisko);
	printf("Zadajte rok vydania:  ");
	scanf("%d", &(*kniznica)[*pocet].rok);
		
	(*pocet)++;
}

KNIHA *zmaz(KNIHA *kniznica, int *pocet, int *velkost) {
   	char c, nazovKnihy[NNAZOV];
   	int i, nevymazane = 0;

   	printf("Zadajte nazov knihy na zmazanie: ");
   	scanf("%s", nazovKnihy);
   	while(getchar()!='\n')
   		;
   		
   	for (i=0; i<*pocet; i++ ) {
   		printf("i: %d, nevymaz: %d\n", i, nevymazane);
		if (!strcmp(nazovKnihy, kniznica[i].nazov)) {
			printf("Vymazat knihu autora: %s %s (%d)? ", kniznica[i].autor.meno, 
				kniznica[i].autor.priezvisko, kniznica[i].rok);
   			c = getchar();
   			while(getchar()!='\n')
   				;
   			if (c == 'a' || c == 'A') {
			   	free(kniznica[i].nazov);
   				continue;
   			}
   		}
		if (i > nevymazane) {
			kniznica[nevymazane] = kniznica[i];
		}  
		nevymazane++;	   
	}
	printf("i: %d, nevymaz: %d\n", i, nevymazane);
	*pocet = nevymazane;
	int realokuj = 0;
	while (*pocet <= *velkost - NBLOK) {
		realokuj = 1;
		*velkost -=NBLOK;
	}
	if (*velkost > 0)
		kniznica = (KNIHA *) realloc(kniznica, *velkost * sizeof(KNIHA));
	else {
		free(kniznica);
		kniznica == NULL;
	}
	return kniznica;
}

int main() {
   	KNIHA *kniznica = NULL;
   	int n = 0, velkost = 0;
	char c; 

	kniznica = nacitaj(kniznica, &n, &velkost); 
	do {
      	vypis(kniznica, n, velkost);
      	printf("p: pridanie\nz: zmazanie\nk: koniec\n");
      	c = tolower(getchar());
      	switch(c) {
         	case 'p': pridaj(&kniznica, &n, &velkost); break;
         	case 'z': kniznica = zmaz(kniznica, &n, &velkost); break;
     	}
  	} while (c != 'k');
   	return 0;   
}



