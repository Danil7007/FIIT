#include <stdio.h>
#include <stdlib.h>

typedef struct clovek {
    char meno[30];
    int rocnik;
    struct clovek *dalsi;
} CLOVEK;


int pocetZRocnika(CLOVEK *zac, int rocnik) {
   CLOVEK *akt = zac;
   int p = 0;
   while(akt != NULL) {
      if(akt->rocnik == rocnik)
         p++;
      akt = akt->dalsi;
   }
   return p;
}

CLOVEK *pridajNaKoniec(CLOVEK *zac, CLOVEK *vloz){
   CLOVEK *akt = zac;
   
   if(zac == NULL) return vloz;
   while(akt->dalsi != NULL) 
      akt = akt->dalsi;
   akt->dalsi = vloz;
   return zac;
}

void vypisZoznam(CLOVEK *zac) {
   while(zac != NULL) {
      printf("%s %d\n", zac->meno, zac->rocnik);
      zac = zac->dalsi;
   }
}

CLOVEK *zmazZoznam(CLOVEK *zac) {
	CLOVEK *p;
	while (zac != NULL) {
		p = zac;
		zac = zac->dalsi;
		free(p);
	}
	return NULL;
}

int main() {
	CLOVEK *zac = NULL, *vloz = NULL;
	int i, n, r;
	
	printf("Zadajte pocet prvkov zoznamu: ");
	scanf("%d", &n);
	
	for(i=0; i<n; i++) {
		vloz = (CLOVEK *) malloc(sizeof(CLOVEK));
		printf("Zadajte meno: ");
		scanf("%s", vloz->meno);
		printf("Zadajte rocnik: ");
		scanf("%d", &vloz->rocnik);
		vloz->dalsi = NULL;
		zac = pridajNaKoniec(zac, vloz);
	}
	
	vypisZoznam(zac);
	printf("Zadajte rocnik (pre vypis poctu ziakov z rocnika): ");
	scanf("%d", &r);
	printf("Pocet ziakov z %d. rocnika: %d\n", r, pocetZRocnika(zac, r));
	zac = zmazZoznam(zac);
	return 0;
}

