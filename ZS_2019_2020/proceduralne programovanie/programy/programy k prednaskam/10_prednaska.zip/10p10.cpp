#include<stdio.h>
#include<conio.h>
#include<math.h>

void hanoi(int n, char odkial, char kam, char pom) {
   if(n == 1) 
       	printf("Presun disk %d z %c na %c\n", n, odkial, kam);
   else {
       	hanoi(n-1, odkial, pom, kam);
		printf("Presun disk %d z %c na %c\n", n, odkial, kam);
		hanoi(n-1, pom, kam, odkial);
   	}
}

int main() {
   int disk, presuny;

   printf("Zadajte pocet diskov, s kolkymi chcete hrat:");
   scanf("%d", &disk);
   
   presuny = pow((double) 2, (double) disk)-1;
   printf("\nPocet potrebnych presunov: %d\n", presuny);
   hanoi(disk,'A','C','B');
   return 0;
}

