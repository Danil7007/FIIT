// spojenie usporiadnych poli celych cisel -> do 3. pola
#include <stdio.h>
#define N 20

int merge(int A[], int m, int B[], int n, int C[N]) {
 	int i=0, j=0, k=0;
   	
	while(i < m && j < n) {
      	if(A[i] < B[j]){
         	C[k++] = A[i++];
      	} else{
         	C[k++] = B[j++];
      	}
   	}
 
 	// doplnenie prvkami pola A, ak este nie su vsetky uz v poli C
   	for(;i < m; i++) {
    	C[k++] = A[i];
   	}

	// doplnenie prvkami pola B, ak este nie su vsetky uz v poli C   
   	for(;j < n; j++) {
      	C[k++] = B[j];
   	}
    return k;
}

int main() {
	int i, pole1[] = {2,3,4,6,8}, pole2[] = {1,5,7,9}, pole3[N];
	int n1, n2, n3;
	
	n1 = sizeof(pole1) / sizeof(int);
	n2 = sizeof(pole2) / sizeof(int);
	n3 = merge(pole1, n1, pole2, n2, pole3);	
	//printf("%d %d %d \n", n1, n2, n3);

	for(i=0; i<n3; i++) {
		printf("%d ", pole3[i]);
	}
	return 0;
}
