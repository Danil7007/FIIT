// co vypisu funkcie?
#include <stdio.h>

void x(char c) {
   if (c >= 'A') {
		printf("%c", c);
    	x(c-1);
    	printf("%c", c);
   }
}
 
void y(char c) {
   if (c >= 'A') {
    	y(c-1);
		printf("%c", c);
    	y(c-1);
   }
}
 

int main() {
	x('C');
	printf("\n");
	y('C');
	return 0;
}
