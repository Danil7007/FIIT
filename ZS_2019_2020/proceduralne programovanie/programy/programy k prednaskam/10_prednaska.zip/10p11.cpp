// Eratostenovo sito - zistenie prvocisel vyskrtavanim nasobkov
#include <stdio.h> 
#include <stdlib.h>
#include <math.h>
#define MAX 100

int main() 
{ 
   int n, i, k, odm; 
   int prv[MAX];

   printf("Do ktoreho cisla hladat prvocisla? (< %d) ", MAX); 
   scanf("%d", &n); 

   n--;     /* znizime n o 1, nevyskrtavame nasobky jednotky */
      
   for(i = 0; i < n; i++)  /* inicializacia */
      prv[i] = i+2;    
   odm = (int) sqrt(n)-1; printf("odmocnina: %d\n", odm);

   for(i = 0; i < odm; i++) {
      if(prv[i] != 0) {     /* ak sme predtym cislo nevyskrtli */
         for(k = i+1; k < n; k++) { /* vyskrtni vsetky nasobky */
            if(prv[k] != 0) {     /* ak este nie je vyskrtnute */
               if(prv[k] % prv[i] == 0)     /* ak je delitelne */
                  prv[k] = 0; 
            } 
         } 
      } 
   } 

   printf("Prvocisla: "); /* vypisanie prvocisel */
   for(i = 0; i < n; i++) 
      if(prv[i] != 0) 
         printf("%d, ", prv[i]); 

   putchar('\n'); 
   return 0;
} 

