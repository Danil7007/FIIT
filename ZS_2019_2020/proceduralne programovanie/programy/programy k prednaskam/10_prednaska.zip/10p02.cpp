// n-ty clen fibonaciho postupnosti - rekurzivne 
#include <stdio.h>

long fib(long n)
{
   if (n <= 2) 
      return n-1;
   else 
      return fib(n-2) + fib(n-1);
}

int main() {
	int n;
	
	printf("Zadajte, ktory clen postupnosti vypisat: ", &n);
	scanf("%ld", &n);
	printf("%ld-ty clen Fibonaciho postupnosti: %ld\n", n, fib(n));
	
	return 0;
}
