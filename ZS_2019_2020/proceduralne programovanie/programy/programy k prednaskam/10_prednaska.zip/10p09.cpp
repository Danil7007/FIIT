// Zisti, kolko najmenej znakov je treba doplnit, aby bolo slovo palindrom
#include <stdio.h>
#define min(x, y) ((x)<(y) ? (x) : (y))
#define N 100

int palindrom(char p[], int d, int h);

int main()
{

   int n = 0;
   char c, p[N];

   printf("Zadajte slovo: ");
   while((c = getchar()) != '\n')
      p[n++] = c;
   printf("Na palindrom je potrebne doplnit %d pismen.\n", 
           palindrom(p, 0, n-1));
   return 0;
}

int palindrom(char p[], int d, int h)
{
   if (h <= d)
      return 0;
   if (p[d] == p[h])
      return palindrom(p, d+1, h-1);

   return 1 + min(palindrom(p, d, h-1), palindrom(p, d+1, h));
}

