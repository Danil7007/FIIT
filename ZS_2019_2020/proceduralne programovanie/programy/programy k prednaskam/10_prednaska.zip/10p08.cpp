// najde najvacsi prvok pola - rekurzivne
#include <stdio.h>

int najvacsi(int pole[], int i) {
	if (i == 0) 
		return pole[i];
	else {
		int  max= najvacsi(pole, i-1);
		if (pole[i] > max)
			return pole[i];
		else 
			return max;
	}
}

int main() {
	int p[] = {5, 6, 3, 7, 10, 2, 8, 4};
	int n = sizeof(p) / sizeof(int);
	
	printf("Najvacsi prvok pola: %d\n", najvacsi(p, n-1));
	return 0;
}
