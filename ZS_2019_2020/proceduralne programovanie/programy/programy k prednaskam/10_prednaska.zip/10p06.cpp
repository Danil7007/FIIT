// Vypis hodnot pola - rekurzivna funkcia
#include <stdio.h>

void vypisPole(int pole[], int i, int n);


int main(void) {
	int p[] ={5, 3, 1, 8, 6, 9, 2, 4, 7, 10};
	int velkost = sizeof(p) / sizeof(int);

	vypisPole(p, 0, velkost);
	return 0;
}

void vypisPole(int pole[], int i, int n) {
	if(i < n) {
		vypisPole(pole, i+1, n);
		printf("%d ", pole[i]);
	}
}



