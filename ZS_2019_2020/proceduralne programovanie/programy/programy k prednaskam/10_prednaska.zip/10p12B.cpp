// spojenie usporiadnych poli celych cisel -> do prveho z poli
// pre zjednodusenie: spajame cast poli obsahujucu nenulove hodnoty
#include <stdio.h>
#define N 20

int merge(int A[], int m, int B[], int n) {
 	int k = n+m;
   	while(m > 0 && n > 0){
      	if(A[m-1] > B[n-1]){
         	A[m+n-1] = A[m-1];
         	m--;
      	} else{
         	A[m+n-1] = B[n-1];
         	n--;
      	}
   	}
 
   	while(n > 0){
    	A[m+n-1] = B[n-1];
      	n--;
   	}
   	return k;
}

// pocet nenulovych prvkov pola
int pocetNenulovychPrvkov(int p[], int max) {
	int i;
	for(i=0; i<max; i++)
		if(p[i] == 0)
			break;
	return i;
}

int main() {
	int i, pole1[N] = {2,3,4,6,8}, pole2[N] = {1,5,7,9};
	int n1, n2, n3;
	
	n1 = pocetNenulovychPrvkov(pole1, N);
	n2 = pocetNenulovychPrvkov(pole2, N);
	printf("%d %d \n", n1, n2);
	n3 = merge(pole1, n1, pole2, n2);	
	

	for(i=0; i<n3; i++) {
		printf("%d ", pole1[i]);
	}
	return 0;
}
