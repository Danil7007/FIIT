// Vypis hodnot - rekurzivna funkcia
#include <stdio.h>

void vypis1(int n);
void vypis2(int n);

int main(void) {
	int n;
	
	printf("Zadajte hodnotu: ");
	scanf("%d", &n);
	vypis2(n);
	return 0;
}

void vypis1(int n) {
	if(n == 0)
		return;
	vypis1(n-1);
	printf("%d ", n);
}

void vypis2(int n) {
   if (n > 0) {
   		vypis2(n-1);
      	printf("%d ", n);
      
   }
}

