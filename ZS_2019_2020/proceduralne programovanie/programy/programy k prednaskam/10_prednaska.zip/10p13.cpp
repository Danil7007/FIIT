#include <stdio.h>
#include <ctype.h>

int sekvencne(int pole[], int n, int x); 
int binarne(int pole[], int n, int x);

int main()
{ 
   int p[100], i, n, x, vysl;
   char c;

   printf("Zadaj pocet prvkov pola (<100): ");
   scanf("%d", &n);

   if (n >= 100) {
      printf("Prilis velky pocet prvkov...\n");
      return 1;
   }
	
   for (i=0; i<n; i++) {
      printf("p[%d]: ", i);
      scanf("%d", &p[i]);
   }
   printf("Zadajte hodnotu, ktora sa ma vyhladat: ");
   scanf("%d", &x);
   while(getchar() != '\n');
   printf("Vyhladavat Binarne alebo Sekvencne? [b/s]: ");
   c = getchar();

   printf("%c\n", c);
   if ((c = tolower(c)) == 's') 
      vysl = sekvencne(p, n, x);
   else if (c == 'b') 
      vysl = binarne(p, n, x);
   else {
      printf("Zadali ste nespravnu hodnotu.\n");
      return 1;
   }

   if (vysl > -1) 
      printf("Index hladanej hodnoty je %d.\n",vysl);
   else 
      printf("Hladana hodnota sa v poli nenachadza.\n");
   return 0;
}

int sekvencne(int pole[], int n, int x) 
{
   int i=0;
	
   while(i < n && pole[i] < x) 
      i++;
   if(i<n && pole[i] == x)
      return i;
   return -1;
}

int binarne(int pole[], int n, int x)
{ 
   int m, l = 0, r = n-1;

   while (l <= r) { 
      m = (l + r) / 2;

      if (x == pole[m])
         return m;
      if (x < pole[m]) 
         r = m - 1;
      else
         l = m + 1;
   }
	
   if (pole[m] == x) 
      return m;
   else 
      return -1;
}

