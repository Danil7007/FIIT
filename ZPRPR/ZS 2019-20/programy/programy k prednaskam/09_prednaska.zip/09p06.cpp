// opakovanie poli a ukazovatelov
// naplnenie a vypis pola - pomocou indexov a ukazovatelov
#include <stdio.h>

int main() {
	int i = 0, pole[10],  *p;
	
	p = &i;
	pole[*p] = *p;
 
 	// indexy: naplnenie pola cislami od 10 po 1
	for (i=0; i<10; i++)
		   pole[i] = 10 - i;
	for (i=0; i<10; i++)
		printf("%d ", pole[i]);
	printf("\n");
 
 	// ukazovatele: naplnenie pola parnymi cislami od 20 po 2
	for (p = pole; p<pole+10; p++)
   		*p = 20 - 2*(p-pole);
   	for (p = pole; p<pole+10; p++)
		printf("%d ", *p);
	printf("\n");
	return 0;
}

