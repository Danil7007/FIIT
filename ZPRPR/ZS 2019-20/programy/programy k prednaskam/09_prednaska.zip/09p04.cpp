// najdenie najdlhsieho a najkratsieho slova v nacitanom riadku
// vyuzitie funkcii na pracu s retazcami
#include <stdio.h>
#include <string.h>
#define N 100

int main() {
	char str[N], slovo[N], maxSlovo[N], minSlovo[N], *p;
	int max = -1, min, len;
	
	gets(str);
	p = str;
	
	while (sscanf(p, "%s", slovo) == 1)  {
		len = strlen(slovo);
		printf("- %s - %d\n", slovo, len);
		if(max == -1) {
			strcpy(maxSlovo, slovo);
			strcpy(minSlovo, slovo);
			min = max = len;
		}
		else if(len > max) {
			strcpy(maxSlovo, slovo);
			max = len;
		}
		else if (len < min) {
			strcpy(minSlovo, slovo);
			min = len;
			
		}
		p = strstr(p, slovo);
		p += len;
	}
	printf("Najdlhsie slovo: %s\n", maxSlovo);
	printf("Najkratsie slovo: %s\n", minSlovo);		
	return 0;
}
