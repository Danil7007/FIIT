// otocenie slov v riadku - slova budu oddelene vzdy len jednou medzerou
// vyuzitie funkcii na pracu s retazcami
#include <stdio.h>
#include <string.h>
#define N 1000

void otocSlova(char s[], char o[]);

int main() {
	char str[N], otoc[N];
	
	printf("Zadajte riadok: ");
	gets(str);

	otocSlova(str, otoc);
	puts(otoc);
	return 0;
}

void otocSlova(char s[], char o[]) {
	char pom1[N], pom2[N], *p = s;
	int d;
	
	o[0] = '\0';

	while(sscanf(p, "%s", pom1) == 1) {
		strcpy(pom2, o);
		strcpy(o, pom1);
		strcat(o, " ");
		strcat(o, pom2);
		p = strstr(p, pom1) + strlen(pom1);
	}
}
