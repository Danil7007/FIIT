// vypocet priemeru a sumy kladnych cisel pola pre interval zadany dolnym a hornym indexom
#include <stdio.h>
#define MAX 10

double priemer(int pole[], int d, int h) {
	if(d<0 || h>MAX || d>h)
		return -1;
		
	double sum = 0;
	int i;
	for(i=d; i<=h; i++)
		sum += pole[i];
	return sum/(h-d+1);
}

int sucet(int pole[], int d, int h) {
	if(d<0 || h>MAX || d>h)
		return -1;
		
	int i, sum = 0;
	for(i=d; i<=h; i++)
		if(pole[i] > 0) 
			sum += pole[i];
	return sum;
}

int main(void) {
	int pole[] = {5,3,-4,1,-1,0,8,-3,2,6};
	int d, h;
	
	printf("Nacitaj dolny index: ");
	scanf("%d", &d);
	printf("Nacitaj horny index: ");
	scanf("%d", &h);
	printf("Priemer cisel medzi indexami %d a %d je %f\n", d, h, priemer(pole, d, h));
	printf("Sucet kladnych cisel medzi indexami %d a %d je %d\n", d, h, sucet(pole, d, h));
	return 0;
}

