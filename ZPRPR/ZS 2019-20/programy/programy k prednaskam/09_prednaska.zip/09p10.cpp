// makro obvod_obdlznika: ukazka potreby zatvoriek obalujucich telo makra
// bez zatvoriek: pri doplneni do vyrazu dava chybne vysledky
#include <stdio.h>

#define obvod_obdlznika(a, b) 2*(a) + 2*(b)	// chybaju zatvorky obalujuce telo makra
//#define obvod_obdlznika(a, b) (2*(a) + 2*(b))

int main(void) {
  int a = 2,
      b = 3;

  printf("Obvod obdlznika O(%d, %d): %d\n", a, b, obvod_obdlznika(a, b));
  printf("2* obvod obdlznika O(%d, %d): %d\n", a, b, 2*obvod_obdlznika(a, b));

  return 0;
}

