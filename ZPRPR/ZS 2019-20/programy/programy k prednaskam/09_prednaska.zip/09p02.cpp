// vyuzitie formatovaneho zapisu do retazca 
// funckia uradnik vytvori spravu pre funkciu sef
#include <stdio.h>

void uradnik(char s[], double r) {
  double obsah, obvod;

  obsah = 3.14 * r * r;
  obvod = 2 * 3.14 * r;
  sprintf(s, "Kruh s polomerom %f ma obsah %f a obvod %f", 
     r, obsah, obvod);
}

void sef(void) {
  char sprava[100];

  uradnik(sprava, 5.0);
  printf("Sprava o kruhu je:\n %s\n", sprava);
}
 
int main() {
	sef();
	return 1;
}
