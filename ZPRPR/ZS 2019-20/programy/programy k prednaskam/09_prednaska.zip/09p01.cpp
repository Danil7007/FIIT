// vyuzitie formatovaneho citania z a do retazca na prevody:
// retazec -> cislo v 16 sustave, cislo v 16 sustave -> cislo v 8 sustave
#include <stdio.h>
int main() {
   int i;
   char s1[5], s2[10];

   printf("Zadaj 4 hexa cislice: ");

   scanf("%s", s1);
   sscanf(s1, "%x", &i);	// z retazca precitame cislo v 16 sustave
   sprintf(s2, "%o", i);	// do retazca nacitame cislo v 8 sustave
   printf("%s\n", s2);
   return 0;
}

