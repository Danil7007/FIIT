// najdenie posledneho vyskytu hodnoty v poli (analogia strrchr())
#include <stdio.h>
#define MAX 100

int *poslVyskyt(int pole[], int n, int hodnota) {
	int *p;
		
	for(p = pole +n-1; p >= pole ; p--) {
		if (*p == hodnota) 
			break;
	} 
	if (p >= pole) 
		return p;
	else
		return NULL;	
}

int main(void) {
	int pole[] = {5,-3,-4,6,-1,0,8,-3,2,6};
	int *p, h;
	
	printf("Nacitaj hodnotu: ");
	scanf("%d", &h);
	
	p = poslVyskyt(pole, sizeof(pole) / sizeof(int), h);
	if (p != NULL) 
		printf("Posledny vyskyt hodnoty %d je medzi na indexe %d\n", h, p-pole);
	else
		printf("Hodnota %d sa v poli nenachadza\n", h);
	return 0;
}


