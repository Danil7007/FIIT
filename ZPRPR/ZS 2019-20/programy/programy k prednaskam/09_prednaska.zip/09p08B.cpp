// vypisanie prvych k riadkov suboru
#include <stdio.h>

int main() {
   FILE *f;
   int c, k, riadok;
   if((f=fopen("beatles.txt", "r")) == NULL) {
      printf("Subor sa nepodarilo otvorit\n");
      return 0;
   }
   scanf("%d", &k);
   riadok = 1;
   while((c=getc(f)) != EOF && riadok <= k) {
      putchar(c);
      if(c == '\n')
         riadok++;
   }
   if(fclose(f) == EOF)
      printf("Subor sa nepodarilo zatvorit\n");
   return 0;
}

