// ladiace vypisy
// program nasobi 2 cisla pomocou scitania
#include <stdio.h>
#define LADENIE

int main() {
   int x, y, nasobok = 0;

   printf("Zadajte dve cisla: ");
   scanf("%d %d", &x, &y);

   printf("%d * %d = ", x, y);
   for(; y>0; y--) {
      nasobok += x;

#ifdef LADENIE
	printf("\n(y: %d, nasobok: %d)\n", y, nasobok);
#endif

   }
   printf("%d\n", nasobok);
   return 0;
}

