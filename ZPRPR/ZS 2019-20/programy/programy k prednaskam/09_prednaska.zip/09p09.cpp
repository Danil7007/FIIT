// makro na_tretiu: ukazka potreby zatvoriek obalujucich premennu
// bez zatvoriek: pri doplneni vyrazu dava chybne vysledky
#include <stdio.h>

//#define na_tretiu(x) (x * x * x)	// chybaju zatvorky obalujuce premennu
#define na_tretiu(x) ((x) * (x) * (x))

int main(void) {
  int i = 2,
      j = 3;

  printf("%d^3 = %d\n", 3, na_tretiu(3));
  printf("%d^3 = %d\n", i, na_tretiu(i));
  printf("%d^3 = %d\n", 2+3, na_tretiu(2+3));
  printf("%d^3 = %d\n", i*j+1, na_tretiu(i*j+1));
  return 0;
}

