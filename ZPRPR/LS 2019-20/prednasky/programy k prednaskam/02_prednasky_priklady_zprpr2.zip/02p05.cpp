// vyhradenie miesta pre n prvkov, nacitanie a vypocitanie sucinu
// dynamicke pole
#include <stdio.h>
#include <stdlib.h>

int *alokuj(int n);
void nacitaj(int *p_i, int n);
void sucin(int *p, int n, int *sucin);

int main()
{
   int *cisla, suc, n;
   printf("Zadajte pocet prvkov pola: ");
   scanf("%d", &n); 

   cisla = alokuj(n);
   nacitaj(cisla, n);
   sucin(cisla, n,&suc);
   printf("Sucin je: %d\n", suc);
   return 0;
}


int *alokuj(int n)
{
    return ((int *) malloc(n * sizeof(int)));
}

void nacitaj(int *p_i, int n)
{
    int i;

    for (i = 0; i < n; i++) {
        printf("Zadajte %d-te cislo: ", i+1);
        scanf("%d", p_i + i);
	}	
}

void sucin(int *p, int n, int *sucin)
{
    int i;

    *sucin = 1;
    for (i = 0; i < n; i++)
        *sucin *= *(p + i);
}

