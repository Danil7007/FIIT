// vlozenie znaku do retazca na danu poziciu
// dynamicke pole
// zvacsovanie pola, ked je potreba
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 10
#define SIZE 20

char *vloz(char *str, char c, int i, int *n) {
	int j, len = strlen(str);
	
	if (len+2 > *n) {
		(*n) += SIZE;
		printf("*");
		str = (char *) realloc(str, *n);
	}
	if (i<0) i = 0;
	if (i>len) i = len;
	
	for(j=len; j>=i; j--)
		str[j+1] = str[j];
	str[i] = c;
	return str;
}

int main() {
	char *str, c;
	int cpom, n, pos;
	
	str = (char *) malloc(N);
	n = N;
	printf("Zadajte retazec znakov (max. %d): ", N);
	fgets(str, N, stdin);
	if (strchr(str, '\n') == NULL) 		// neprecital sa cely riadok
		while((cpom = getc(stdin)) != '\n' && c != EOF)
			;
	else {		// precital sa cely riadok - treba odstranit \n - posledny znak
		int len = strlen(str);
		str[len-1] = '\0';
	}
	printf("Nacitany retazec: %s\n", str);
	printf("Zadajte znak na vlozenie do retazca: ");
	scanf("%c", &c);
	printf("Zadajte poziciu, kam sa bude znak vkladat: ");
	scanf("%d", &pos);
	
	int i;
	for(i=0; i<100; i++)
		str = vloz(str, c, pos, &n);
	
	printf("Retazec po vlozeni znaku: %s\n", str);
	return 0;
}

