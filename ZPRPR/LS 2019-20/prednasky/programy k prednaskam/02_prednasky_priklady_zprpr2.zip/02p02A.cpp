// vlozenie znaku do retazca na danu poziciu
// staticky
//pristup k prvkom pola pomocou ukazovatela
#include <stdio.h>
#include <string.h>
#define N 10

int vloz(char str[], char c, int i, int n) {
	int len = strlen(str);
	char *p;
	
	if (len+2 > n) return 0;
	if (i<0) i = 0;
	if (i>len) i = len;
	
	for(p=str+len; p>=str+i; p--)
		*(p+1) = *(p);
	*(p+1) = c;
	return 1;
}

int main() {
	char str[N], c;
	int cpom, pos;
	
	printf("Zadajte retazec znakov (max. %d): ", N);
	fgets(str, N, stdin);
	if (strchr(str, '\n') == NULL) 		// neprecital sa cely riadok
		while((cpom = getc(stdin)) != '\n' && c != EOF)
			;
	else {		// precital sa cely riadok - treba odstranit \n - posledny znak
		int len = strlen(str);
		str[len-1] = '\0';
	}
	printf("Nacitany retazec: %s\n", str);
	printf("Zadajte znak na vlozenie do retazca: ");
	scanf("%c", &c);
	printf("Zadajte poziciu, kam sa bude znak vkladat: ");
	scanf("%d", &pos);
	
	int i;
//	for(i=0; i<100; i++)
		vloz(str, c, pos, N);
	
	printf("Retazec po vlozeni znaku: %s\n", str);
	return 0;
}

