// vzacne pismena
// pristup do pola pomocnym ukazovatelom
#include <stdio.h>
#include <ctype.h>
#define N 26
#define SUBOR "list.txt"

void vznacnePismena(int k, int hist[]) {
	int *p;
	for (p=hist; p<=hist+N; p++) 
		if (*p < k) 
			printf("%c ", 'A'+p-hist);
	printf("\n");	
}

int main() {
	FILE *text;
	int c, pocet;
	int hist[N] = {0};
	
	if ((text = fopen(SUBOR, "r")) == NULL)
		return 0;
		
	while ((c=getc(text)) != EOF)
		if (isalpha(c)) (*(hist + toupper(c) -'A'))++;
	
	printf("Zadajte pocet vyskytov: ");
	scanf("%d", &pocet);
		
	vznacnePismena(pocet, hist);
	return 0;
}
