// teplotne vykyvy
// pristup do pola pomocnym ukazovatelom
#include <stdio.h>
#define N 20


void teplotneVykyvy(double teploty[], int n, double rozdiel) 
{
   double *p;   // ukazovatel na pristup k prvkom pola
   for (p = teploty; p < teploty + n-1; p++)   
         
      if (*(p + 1) - *p > rozdiel || *(p + 1) - *p < (-1)*rozdiel)

         printf("%d\n", p+1-teploty);
}

int main() {
	double teploty[N] = {3, 5, 17, 19, 6, 3, 3, 0, 10, 10, -5, -3, -2, -1, 0, 1};
	
	teplotneVykyvy(teploty, N, 5);
	
	return 0;
}
