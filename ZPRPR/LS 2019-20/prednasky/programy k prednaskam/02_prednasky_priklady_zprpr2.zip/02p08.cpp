// nacitanie lubovolne dlheho vstupu
#include <stdio.h>
#include <stdlib.h>

int main()
{
    unsigned int lenMax = 128;
    unsigned int size;
    
    char *pStr = (char *) malloc(lenMax);
    size = lenMax;

    if(pStr != NULL)
    {
    	printf("Zadajte velmi dlhy retazec znakov: ");
		int c = EOF;
		unsigned int i = 0;
        // citaj vstup pokym nepride koniec riadku alebo subora
		while ((c = getchar()) != '\n' && c != EOF)
		{
			pStr[i++]=(char)c;

			// ak i dosiahne maximalnu velkost pol, zvacsi pole
			if(i == size)
			{
            	size = i+lenMax;
            	//printf("*");
				pStr = (char *) realloc(pStr, size);
			}
		}

		pStr[i] = '\0';

        printf("Dlhy retazec: %s\n", pStr);
        
		free(pStr);		// na konci uvolni pamat
		pStr = NULL;
    }
    return 0;
}
