// podmienky
#include <stdio.h>

int main()
{
    int i = 1, j = 1, l = 0, k;
	
//	k = i == 1;
//	k = i != 1;
//	k = i && (j == 3);
//	k = !i && j;
//	k = (i = 2) || j;			// meni sa hodnota i
//	k = i || (j / 2);
//	k = (i == 5) || (j % 2);
//	k = !i || (j = j - 1);  	// meni sa hodnota j
//	k = i || (j = j - 1);   	// hodnota j sa nemeni
//	k = i < 0 && --i % 2;		// hodnota i sa nemeni
//	k = i >= 0 && --i % 2;		// meni sa hodnota i
//	k = l++ || (-1)*i; 			// meni sa hodnota l
	
	printf("i: %d j: %d k: %d\n", i, j, k);


	return 0;
}
