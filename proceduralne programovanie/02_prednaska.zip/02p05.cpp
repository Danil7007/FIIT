// float a double - presnost
#include <stdio.h>

int main()
{
    float  f = 3.1415926535897932384;
	double d = 3.1415926535897932384;
	
	printf("pi: f = %.8f, d = %.8f, d = %g\n", f, d, d);

	return 0;
}
