// vypis specialnych znakov

#include <stdio.h>

int main()
{
	printf("\npercento: %");
	printf("\nlomka: \");
	printf("\nuvodzovka: """);
	
	return 0;
}
