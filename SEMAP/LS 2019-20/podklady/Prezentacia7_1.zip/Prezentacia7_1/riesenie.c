// Seminar s algoritmizacie a programovania 2019/2020
// FIIT STU, Bratislava

// Kytica - doplnte komentare

#include <stdio.h>
#include <stdlib.h>

// (1): 
#define MAXN 1000
#define MAXSUM 1000000

int d[MAXN]; // (2): 
int nd, limit; // (3): 
char sum[MAXSUM+1]; // (4): 

int solve()
{
  int i, j, max = 0;
  sum[0] = 1; // (5): 
  for (i = 0; i < nd && max < limit; i++) // (6): 
    if (d[i] <= limit) // 
    {
      for (j = max; j >= 0; j--) // (8): 
      {
        if (sum[j] > 0) // (9): 
        {    
          if (j + d[i] <= limit) // (10): 
          {
            sum[j+d[i]] = 1; // (11): 
            
            if (max < j + d[i]) // (12): 
              max = j+d[i];
          }
        }
      }
    }
  return max;
}

int main()
{
  int i, j;
  while (scanf("%d %d", &nd, &limit) > 0)
  {
    // (13): 
    j = 0;
    for (i = 0; i < nd; i++)
    {
      scanf("%d", &d[i]);
      if (d[i] <= limit)
        j += d[i];
    }
    if (j > limit)
      j = limit;
    for (i = 0; i <= j; i++)
      sum[i] = 0;
  
    printf("%d\n", solve());
  }
  return 0;
}
