// Seminar s algoritmizacie a programovania 2019/2020
// FIIT STU, Bratislava

// Rytierske hry - doplnte komentare

#include <stdio.h>

#define MAXN 10
#define MAXSUM 50

// (1): 
int c[MAXN], n, sum;
// (2): 
int a[MAXSUM];

// (3): 
void print(int k)
{
  int i;
  // (4): 
  if (k == sum)
  {
    // (5): 
    for (i = 0; i < sum; i++)
      printf("%d ", a[i]+1);
    printf("\n");
    return;
  }
  
  // (6): 
  for (i = 0; i < n; i++)
    if (c[i] > 0)
    {
      c[i]--; // (7): 
      a[k] = i; // (8): 
      print(k+1); // (9): 
      c[i]++; // (10): 
    }
}

int main(void)
{
  int i;
  // (11): 
  scanf("%d", &n);
  for (i = sum = 0; i < n; i++)
  {
    scanf("%d", &c[i]);
    sum += c[i];
  }
  // (12): 
  print(0);
  return 0;
}
