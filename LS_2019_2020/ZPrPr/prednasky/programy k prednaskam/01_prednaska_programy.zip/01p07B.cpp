// REKURZIVNA FUNKCIA: suscet cisel od 1 po n, ktore su delitelne ciskom k
#include <stdio.h>

int sucet(int n, int k) {
	if (n > 0) {
		if (n % k == 0)
			return n + sucet(n-1, k);
		else 
			return sucet(n-1,k);	
	}
	else return 0;
}

int main() {
	int n, k;
	printf("Zadajte n: ");
	scanf("%d", &n);
	printf("Zadajte k: ");
	scanf("%d", &k);
	printf("sucet cisel od 1 do %d delitelnych cislom %d: %d\n", n, k, sucet(n, k));
	return 0;
}
