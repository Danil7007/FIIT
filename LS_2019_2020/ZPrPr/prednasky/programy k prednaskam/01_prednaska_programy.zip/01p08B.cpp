// kontrola vnorenych zatvoriek jedneho druhu
#include <stdio.h>
#include <string.h>

int skontrolujSubor(FILE *f) {
	int c, pocetz = 0;
	
	while((c = getc(f)) != EOF) {
		if (c == '(') 
			pocetz++;
		else if (c == ')') 
			if (pocetz <= 0)
				return 0;
			else 
				pocetz--;
	}
				 
	if(pocetz == 0)
		return 1;
	else 
		return 0;
}

int main(){
	FILE *f;
	
	if ((f=fopen("zatvorky.txt", "r")) == NULL) {
		printf("Subor sa nepodarilo otvorit.\n");
		return 0;
	}
	
	
	if(skontrolujSubor(f))
		printf("Subor je dobre uzatvorkovany.\n");
	else
		printf("Subor nie je dobre uzatvorkovany.\n");
		
	fclose(f);
	return 0;
}
