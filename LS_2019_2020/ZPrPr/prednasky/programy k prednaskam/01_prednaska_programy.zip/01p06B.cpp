// MODULARNA ARITMETIKA: zistenie casu konca udalosti 
// s danou dlzkou trvania v hod a min.
#include <stdio.h>

int main() {
	int hodiny, minuty, trvhod, trvmin, prenos;
	
	printf("Zadajte cas vo formate hh:mm\n");
	scanf("%d:%d", &hodiny, &minuty);
	printf("Zadajte trvanie vo formate hh:mm\n");
	scanf("%d:%d", &trvhod, &trvmin);
	
	prenos = (minuty + trvmin) / 60;
	minuty = (minuty + trvmin) % 60;
	hodiny = (hodiny + trvhod + prenos) % 24;
	
	printf("Po prejdeni %2d:%2d minut je %02d:%02d hodin.\n", trvhod, trvmin, hodiny, minuty);
		
	
	return 0;
}
