// doplnanie podmienok - zistenie, ci vsetky prvky pola su prvocisla
#include <stdio.h>
#include <math.h>
#define N 10

int jePrvocislo(int x) {
	int k;
	double s = sqrt(x);
	for(k=2; k<= s; k++) 
		if(x % k == 0) return 0;
	return 1;	
}

int main() {
	int i = 0, pole[N] = {3, 5, 7, 11, 17, 19, 23, 29, 31, 37}; 
	while(i<N && jePrvocislo(pole[i]))  
   		i++;
	if(i==N) 
   		printf("vsetky prvky pola su prvocisla\n");
   	else 
   		printf("nie vsetky prvky pola su prvocisla\n");
   		
   	return 0;
}
