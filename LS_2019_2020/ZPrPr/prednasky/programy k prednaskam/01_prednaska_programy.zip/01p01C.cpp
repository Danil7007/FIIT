// makro na vypocet absolutnej hodnoty
#include <stdio.h>
#define abs(x) (x < 0 ? -(x) : x)

int main() {
	printf("abs(5-7) = %d\n", abs(5-7));
	printf("-5*abs(2) = %d\n", -5*abs(2));
	
}
