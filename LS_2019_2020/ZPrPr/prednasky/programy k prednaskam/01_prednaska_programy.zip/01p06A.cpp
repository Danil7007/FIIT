// MODULARNA ARITMETIKA: zistenie casu konca udalosti 
// s danou dlzkou trvania v min.
#include <stdio.h>

int main() {
	int hodiny, minuty, trvanie, prenos;
	
	printf("Zadajte cas vo formate hh:mm\n");
	scanf("%d:%d", &hodiny, &minuty);
	printf("Zadajte trvanie v minutach\n");
	scanf("%d", &trvanie);
	
	prenos = (minuty + trvanie) / 60;
	minuty = (minuty + trvanie) % 60;
	hodiny = (hodiny + prenos) % 24;
	
	printf("Po prejdeni %d minut je %02d:%02d hodin.\n", trvanie, hodiny, minuty);
		
	
	return 0;
}
