// program zisti, ci znaky v nacitanom retazci su usporiadne
#include <stdio.h>
#include <string.h>

int analyzujStr(char str[]) {
	int len, i;

	len = strlen(str);
	for (i=1; i<len; i++) {
		if (str[i] < str[i-1])
			return 0;
	}
	return 1;
}

int main() {
	char string[50];
	
	printf("Zadajte retazec znakov (slovo): ");
	scanf("%s", string);
	
	printf("znaky retazca %s %ssu usporiadane\n", string, analyzujStr(string) ? "" : "nie ");
	return 0;
}
