// program vytvori postupku pismen
// funkcia postupka vrati cez argumenty index najnizsieho a najvyssieho znaku
#include <stdio.h>
#include <string.h>

void postupka(char post[], char z, int len, int *mini, int *maxi) {
	int i;

	*mini = *maxi = 0;
	
	for (i=0; i<len; i++) {
		post[i] = z;
		z++;
		if (z > 'z')
			z = 'a';		
		if (post[i] < post[*mini]) 
			*mini = i;
		if (post[i] > post[*maxi]) 
			*maxi = i;
	}
	post[len] = '\0';
}

int main() {
	char z, post[50];
	int l, min, max;
	
	printf("Zadajte pociatocny znak: ");
	scanf("%c", &z);
	printf("Zadajte dlzku postupky: ");
	scanf("%d", &l);
	
	if(l >= 50) 
		printf("Prilis dlha postupka.\n");
	else {
		postupka(post, z, l, &min, &max);
		printf("postupka: %s,\nindex najmensieho: %d, index najvacsieho: %d\n", post, min, max);
}
	return 0;
}

