// vypis suboru okrem textu v zatvrokach (uloha zo skusky)
#include <stdio.h>
#include <string.h>

void vypisSubor(FILE *f) {
	int c, zatvorka = 0;
	
	while ((c = getc(f)) != EOF) {		
		if (c == '(') 
			zatvorka = 1;
		if (!zatvorka)
			putchar(c);
		if (c == ')') 
			zatvorka = 0;
	}
}

int main(){
	FILE *f;
	
	if ((f=fopen("zatvorky nevnorene.txt", "r")) == NULL) {
		printf("Subor sa nepodarilo otvorit.\n");
		return 0;
	}
	
	vypisSubor(f);
		
	if(fclose(f) == EOF)
		printf("Subor sa nepodarilo zatvorit.\n");
	return 0;
}
