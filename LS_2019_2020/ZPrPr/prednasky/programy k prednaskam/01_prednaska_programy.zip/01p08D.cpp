// REKURZIVNA FUNKCIA: kontrola zatvoriek rozneho druhu (), {}, []
// zaciatok a koniec suboru su riesene ako specialne zatvorky 'z' a EOF
#include <stdio.h>
#include <string.h>

int skontrolujSubor(FILE *f, char z) {
	int c, pocetz = 0;
	
	while((c = getc(f)) != EOF && c != ')' && c != '}' && c != ']') {
		if (c == '(') 
			if (!skontrolujSubor(f, '(')) 
				return 0;
		if (c == '{') 
			if (!skontrolujSubor(f, '{')) 
				return 0;
		if (c == '[') 
			if (!skontrolujSubor(f, '[')) 
				return 0;
	}
	
	if (z == '(' && c == ')') 
		return 1;
	if (z == '{' && c == '}') 
		return 1;
	if (z == '[' && c == ']') 
		return 1;
	else if (z == 'z' && c == EOF) 
		return 1;
	else 
		return 0;
}

int main(){
	FILE *f;
	
	if ((f=fopen("zatvorky.txt", "r")) == NULL) {
		printf("Subor sa nepodarilo otvorit.\n");
		return 0;
	}
	
	
	if(skontrolujSubor(f, 'z'))
		printf("Subor je dobre uzatvorkovany.\n");
	else
		printf("Subor nie je dobre uzatvorkovany.\n");
		
	fclose(f);
	return 0;
}
