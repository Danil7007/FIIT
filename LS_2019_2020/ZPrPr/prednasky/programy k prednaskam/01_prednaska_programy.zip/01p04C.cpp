// program zisti, ci znaky v nacitanom retazci su usporiadne 
// funkcia anlyzujstr vrati cez argumenty pocty malych a velkych pismen
#include <stdio.h>
#include <string.h>

int analyzujStr(char str[], int *pocetM, int *pocetV) {
	int len, i;

	len = strlen(str);
	*pocetM = *pocetV = 0;
	
	for (i=0; i<len; i++) {		
		if (str[i] >= 'a' && str[i] <= 'z')
			(*pocetM)++;
		if (str[i] >= 'A'&& str[i] <= 'Z')
			(*pocetV)++;
	}
	
	for (i=1; i<len; i++) {		
		if (str[i] < str[i-1])
			return 0;		
	}
	return 1;
}

int main() {
	char string[50];
	int m, v;
	
	printf("Zadajte retazec znakov (slovo): ");
	scanf("%s", string);
	
	printf("znaky retazca %s %ssu usporiadane, ", string, analyzujStr(string, &m, &v) ? "" : "nie ");
	printf("male: %d, velke: %d\n", m, v);
	return 0;
}

