// REKURZIVNA FUNKCIA: vypis cisel od 1 po n, ktore su delitelne ciskom k
#include <stdio.h>

void vypis(int n, int k) {
	if (n > 0) {
		vypis(n-1, k);
		if (n % k == 0)
			printf("%d ", n);
		
	}
}

int main() {
	int n, k;
	printf("Zadajte n: ");
	scanf("%d", &n);
	printf("Zadajte k: ");
	scanf("%d", &k);
	vypis(n, k);
	return 0;
}
