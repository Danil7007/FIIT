#include <stdio.h>
#include <stdlib.h>

void nacitaj(char *pole, int *vyska, int *sirka, int *sucet){
    FILE * subor = fopen("osemsmerovka.txt", "r");
    int i=0;
    char c;
    
    // nacitanie dvoch celych cisiel zo suboru
    fscanf(subor, "%d %d", vyska, sirka);
    *sucet = (*vyska) * (*sirka);
    // alokovanie miesta pre pismena
    pole = (char *)malloc(*sucet);
    
    printf("%d %d %d\n", *vyska, *sirka, *sucet);
    
    // nacitanie velkych pismen zo subora
    while (i < *sucet){
        c = fgetc(subor);
        if (c >= 'A' && c <= 'Z'){
            *(pole+i) = c;
            //printf("%c", *(pole+i));
            i++;
        }
    }
    
    printf("POLE %c \n", *pole);

}

void vypis(char *pole, int *sucet){
    int i;
    
    printf("POLE %d ", *pole);
    
    for (i=0; i < *sucet; i++){
        printf("%d", i);
    }
}

int main(){
    char *pole;
    int m, n, spolu, *pm = &m, *pn = &n, *sp = &spolu;
    int i=0;
    
    nacitaj(pole, pm, pn, sp);
    vypis(pole, sp);

    return 0;
}