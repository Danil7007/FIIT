// Funkcia spocita sucet kladnych cisel v poli 
#include <stdio.h>

int sumaKladnych(int pole[], int n, int *pocet) {
	printf("Velkost pola: %d\n", sizeof(pole)/sizeof(int));
	int i, suma;
   	for(i=0, suma=0, *pocet=0; i<n; i++) 
      	if(pole[i] > 0) {
         	suma += pole[i];
        	(*pocet)++;
      	}
   	return suma;	
}


int main(void)
{
	int p, s;
	int pole[100] = {1, 0, -3, 2, -6};
	
   	printf("Velkost pola: %d\n", sizeof(pole)/sizeof(int)); 
   	s = sumaKladnych(pole, sizeof(pole)/sizeof(int), &p);
  	printf("Suma kladnych cisel: %d, pocet: %d", s, p);
   	return 0;
}
