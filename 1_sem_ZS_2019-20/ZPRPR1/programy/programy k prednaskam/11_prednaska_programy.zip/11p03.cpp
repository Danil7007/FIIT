// Co urobi program pre nacitany retazec, ktory obsahuje znak '?'
#include <stdio.h>
#define N 100

int main(void)
{
	char *p1, *p2 , str[N];
	scanf("%s", str);
	p1 = str;
	for (p2=p1; p2<p1+N && *p2 != '?'; p2++)
    	;
	if (p2 < p1+N) {
   		printf("Pozicia (index) ?: %d\n", p2-p1);
   		for (; p2>=p1; p2--)
    		printf("%c", *p2);
	} 
   return 0;
}
