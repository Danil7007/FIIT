// Ukazka skrateneho vyhodnocovania logickych vyrazov
#include <stdio.h>
int main(void)
{	
   //int i = 5, j = 2;
   int i = 4, j = 2;
   //int i = 6, j = 3;
   if ((i %= j) || ++j == 3)
      printf ("L "); 
   printf("i: %d  j: %d\n", i, j); 
   return 0;
}

