// Vypis cisla v 2-kovej sustave - iterativne a rekurzivne
#include <stdio.h>

void vypis2_iter(int x) {
   while(x > 0) {
      printf("%d", x%2);    
      x /= 2; 
  }
}

void vypis2_rek1(int x) {
   printf("%d", x%2);
   if (x > 1)       
      vypis2_rek1(x/2); 
}

void vypis2_rek2(int x) {
   if (x > 1)       
      vypis2_rek2(x/2); 
   printf("%d", x%2);
}

int main() {
	int cislo;
	scanf("%d", &cislo);
	printf("\nIterativne (v opacnom poradi): ");
	vypis2_iter(cislo);
	printf("\nRekurzivne (v opacnom poradi): ");
	vypis2_rek1(cislo);
	printf("\nRekurzivne (spravne poradie):  ");
	vypis2_rek2(cislo);
	printf("\n");
	
	return 0;
}
