// podla volby pouzivatela sa do pola pozdrav nakopiruje slovensky alebo anglicky pozdrav
// po znakoch
#include <stdio.h>
#include <string.h>

int main() {
	char lan, pozdrav[10], s1[]="ahojte", s2[]="hello";
	int i=0;

	scanf("%c", &lan);
	if(lan == 's') 
   		while (s1[i] != '\0') {
   			pozdrav[i] = s1[i];
   			i++;
		} 		
	else 
		while (s2[i] != '\0') {
			pozdrav[i] = s2[i];
			i++;
		}
	pozdrav[i] = '\0';

	printf("%s\n", pozdrav);
	return 0;
}
