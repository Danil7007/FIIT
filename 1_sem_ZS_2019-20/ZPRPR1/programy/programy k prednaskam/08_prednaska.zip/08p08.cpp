// nacitanie znakov do pola, ich vypis a vypis opacne - ukazovatelova aritmetika
#include <stdio.h>
#define N 50

int main(){
	char znaky[N], *p, c;
	int velkost;

	printf("Zadajte velkost pola: ");
	scanf("%d", &velkost);
	while((c = getchar()) != '\n');	// vyprazdnenie buffera
	
	printf("Zadajte %d znakov:\n", velkost);
	for(p = znaky; p < znaky + velkost; p++)
		scanf("%c", p);
	while((c = getchar()) != '\n');	// vyprazdnenie buffera

	printf("\nZadane znaky:\n");
	for(p = znaky; p < znaky + velkost; p++)
		printf("%c", *p);
   
   printf("\nZadane znaky opacne:\n");
	for(p = znaky + velkost - 1; p >= znaky; p--)
    	printf("%c", *p); 
	return 0;
} 

