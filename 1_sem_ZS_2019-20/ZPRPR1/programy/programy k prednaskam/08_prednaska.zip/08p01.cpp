// ake hodnoty maju premenne?
#include <stdio.h>

int main() {
	int i = 2, j = 3;
	int *p, *q;
	
	p = &i;
	q = &j;
	printf("i: %d, j: %d, *p: %d, *q: %d\n", i, j, *p, *q);
	*p = *p * *q;
	printf("i: %d, j: %d, *p: %d, *q: %d\n", i, j, *p, *q);
	*q = *p + 1;
	printf("i: %d, j: %d, *p: %d, *q: %d\n", i, j, *p, *q);
	 q = p;
	 printf("i: %d, j: %d, *p: %d, *q: %d\n", i, j, *p, *q);
	 *q = *p + 4;
	 printf("i: %d, j: %d, *p: %d, *q: %d\n", i, j, *p, *q);
	 j = *q + *p + i;
	 printf("i: %d, j: %d, *p: %d, *q: %d\n", i, j, *p, *q);
	  
	return 0;
}
