// volanie funkcie odkazom - vypocita sa suma kladnych a suma zapornych hodnot v poli
// program vypocita bilanciu
#include <stdio.h>

void bilancia(double ucet[], int n, double *prijem, double *vydaj);

int main() {
	double ucet[] = {350.0, -25.40, -15.80, -49.99, 1345.70, -236.00, -1500.0};
	double prijem, vydaj;
	int pocet = sizeof(ucet) / sizeof(double);
	
	bilancia(ucet, pocet, &prijem, &vydaj);
	printf("Prijem: %.2f, vydaj: %.2f\n", prijem, vydaj);
	if (prijem + vydaj > 0)
		printf("Usetrili sme!\n");
	return 0;
}

void bilancia(double ucet[], int n, double *prijem, double *vydaj) {
	int i;
	
	for(i=0; i<n; i++)
		if(ucet[i] > 0)
			*prijem += ucet[i];
		else
			*vydaj += ucet[i];		
}

