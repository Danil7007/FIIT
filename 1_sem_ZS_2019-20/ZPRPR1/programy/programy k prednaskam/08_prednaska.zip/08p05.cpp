// staticke pole - premenna je adresou na zaciatok pola
// vypis adries
#include <stdio.h>
#define N 10

int main() {
	int pole[N];
	int *p;
	
	p = pole;
	printf("%u %u", pole, p);
	
	  
	return 0;
}
