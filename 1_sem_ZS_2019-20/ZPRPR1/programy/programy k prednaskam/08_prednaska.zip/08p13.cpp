// spojenie retazcov - strcpy() a strcat()
#include <stdio.h>
#include <string.h>

int main() {
	char subor[20], nazov[10], pripona[5];

	scanf("%s", nazov);
	scanf("%s", pripona);

	strcpy(subor, nazov);
	strcat(subor, ".");
	strcat(subor, pripona);

	printf("%s\n", subor);
	return 0;
}
