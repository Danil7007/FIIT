// formatovane citanie zo suboru - vynechavanie bielych znakov
// vypocet sumy hodnot v subore
#include <stdio.h>

int main() {
    FILE *f;
    int kolko, suma = 0;
    char akcia[2];

    f = fopen("peniaze.txt", "r"); 
    while (fscanf(f, "%1s", akcia) == 1) {   	
        fscanf(f, "%d", &kolko);
        printf("%s %d\n", akcia, kolko);
        suma +=  (akcia[0] == '+') ? kolko : (-1*kolko);
    }
    printf("Spolu: %d\n", suma);
    fclose(f);
    return 0;
}

