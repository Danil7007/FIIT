// funkcia vrati index prveho vyskytu znaku
// pouzitie strch()
#include <stdio.h>
#include <string.h>
#define N 100

int indexVyskytu(char str[], char c) {
	char * p = strchr(str, c);

	if(p == NULL)
		return -1;
	else 
		return p - str;	
}

int main() {
	char s[N], c;
	int i;
	
	printf("Zadajte retazec a hladany znak: ");
	scanf("%s %c", s, &c);

	i = indexVyskytu(s, c);
	if(i != -1)
		printf("Znak %c je v retazci %s na pozicii %d\n", c, s, i);
	else
		printf("Znak %c sa v retazci %s nenachadza\n", c, s);
	return 0;
}
