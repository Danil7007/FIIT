// pristup k prvkom retazca - zmena vsetkych znakov '*' na '+'
// cez indexy
#include <stdio.h>
#include <string.h>
#define N 20

int main() {
	char s[10];
	int i;

	for (i = 0; i < 10-1; i++)
    	s[i] = '*';
	s[10-1] = '\0';

    printf("%s\n", s);
	return 0;
}
