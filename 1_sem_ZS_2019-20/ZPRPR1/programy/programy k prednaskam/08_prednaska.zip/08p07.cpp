// vypise poziciu prveho vyskytu '*' v retazci - ukazovatelova aritmetika
#include <stdio.h>
#define N 10

int main() {
	char *p1, *p2 , str[N] = {'a', 'h', '?', 'j', '\0'};

	p1 = str;

	for (p2=p1; p2<p1+N && *p2 != '?'; p2++)
    	;										// tu mozete vypisovat adresy p1, p2
	
	printf("%d", (p2 < p1+N) ? (p2-p1+1) :-1);

	return 0;
}
