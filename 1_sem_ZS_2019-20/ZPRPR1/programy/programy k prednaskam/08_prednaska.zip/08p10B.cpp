// pristup k prvkom retazca - zmena vsetkych znakov '*' na '+'
// cez ukazovatele
#include <stdio.h>
#include <string.h>
#define N 20

int main() {
	char s[10], *p;

	for (p = s; p < s+10-1; p++)
    	*p = '*';
	*p = '\0';

    printf("%s\n", s);
	return 0;
}
