// do pola m sa skopiruje lexikograficky mensi retazec (skor v abecede)
// pouzitie funkcie strcmp()
#include <stdio.h>
#include <string.h>

int main() {
	char s1[10], s2[10], m[10];

	scanf("%s %s", s1, s2);
	if (strcmp(s1, s2) < 0)
   		strcpy(m, s1);
	else
   		strcpy(m, s2);
   	printf("%s", m);
	return 0;
}

