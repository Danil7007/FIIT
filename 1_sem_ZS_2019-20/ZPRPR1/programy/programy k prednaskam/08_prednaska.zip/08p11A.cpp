// pristup k prvkom retazca - zmena vsetkych znakov '*' na '+'
// cez indexy
#include <stdio.h>
#include <string.h>
#define N 20

int main() {
	char str[N];
	int i, dlzka;

	scanf("%s", str);
	dlzka = strlen(str);
	for(i=0; i<dlzka; i++)
   		if(str[i] == '*')
      		str[i] = '+';
    printf("%s\n", str);
	return 0;
}
