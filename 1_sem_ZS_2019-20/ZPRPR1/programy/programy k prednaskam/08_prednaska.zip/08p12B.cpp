// podla volby pouzivatela sa do pola pozdrav nakopiruje slovensky alebo anglicky pozdrav
// pouzitie funkcie strcpy()
#include <stdio.h>
#include <string.h>

int main() {
	char lan, pozdrav[10], s1[]="ahojte", s2[]="hello";
	int i=0;

	scanf("%c", &lan);
	if(lan == 's') 
   		strcpy(pozdrav, s1);
	else
   		strcpy(pozdrav, s2);

	printf("%s\n", pozdrav);
	return 0;
}
