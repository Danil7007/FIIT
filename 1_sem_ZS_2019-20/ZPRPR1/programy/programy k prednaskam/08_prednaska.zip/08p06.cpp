// vypis retazca - ukazovatelova aritmetika
#include <stdio.h>
#define N 10

int main() {
	
	char *p1, *p2 , str[N] = {'a', 'h', 'o', 'j', '\0'};

	p1 = str;
	p2 = p1;

	while(p2 < p1+ N && *p2 != '\0') 
	    	printf("%c", *p2++);

	return 0;
}
