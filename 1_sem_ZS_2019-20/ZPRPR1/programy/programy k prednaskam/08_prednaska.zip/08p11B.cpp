// pristup k prvkom retazca - zmena vsetkych znakov '*' na '+'
// cez ukazovatele
#include <stdio.h>
#include <string.h>
#define N 20

int main() {
	char str[N], *p;
	int dlzka;

	scanf("%s", str);
	dlzka = strlen(str);
	for(p = str; p < str+dlzka; p++)
   	if(*p == '*')
    	*p = '+';
	printf("%s\n", str);
	return 0;
}
