// do premennej sum vlozi sumu hodnot v i, j, k - pomocou ukazovatelov
#include <stdio.h>

int main() {
	int i, j, k, sum;
	int *p, *s;
	
	scanf("%d %d %d", &i, &j, &k);
	
	s = &sum;	// s ukazuje na sum
	p = &i;		// p ukazuje na i
	*s = *p;	// na miesto, kam ukazuje s prekopiruj hodnotu z miesta, kam ukazuje p
	p = &j;		// p ukazuje na j
	*s += *p;	// na miesto, kam ukazuje s pripocitaj hodnotu z miesta, kam ukazuje p
	*s += k;	// na miesto, kam ukazuje s pripocitaj hodnotu k
	
	printf("%d + %d + %d = %d\n", i, j, k, sum);	  
	return 0;
}
