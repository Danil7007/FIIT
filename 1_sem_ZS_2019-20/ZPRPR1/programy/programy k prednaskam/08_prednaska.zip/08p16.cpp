// najdenie vsetkych vyskytov podretazca
// pouzitie strstr()
#include <stdio.h>
#include <string.h>
#define N 100

void vypisVyskyty(char str[], char pod[]) {
	char *p = str;
	int i = 0;

	while((p = strstr(p, pod)) != NULL) {
		i++;
		if(i==1) 
			printf("Vyskyty %s v retazci %s: %d", pod, str, p-str);
		else
			printf(", %d", p-str);
		p++;
	}
	if(i==0)
		printf("Podretazec %s sa v retazci %s nenachadza\n");
	else
		printf("\n");	
}

int main() {
	char s[N], p[N];
	
	printf("Zadajte retazec a hladany podratazec: ");
	scanf("%s %s", s, p);

	vypisVyskyty(s, p);
	return 0;
}
